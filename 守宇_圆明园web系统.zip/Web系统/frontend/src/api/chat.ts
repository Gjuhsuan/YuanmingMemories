/**
 * SSE 流式封装 —— POST + ReadableStream 解析。
 *
 * 原生 EventSource 不支持 POST，因此用 fetch + ReadableStream 手动解析。
 */
export interface SSEEvent {
  event: string
  data: any
}

export async function* streamChat(
  body: Record<string, any>,
  signal?: AbortSignal,
): AsyncGenerator<SSEEvent> {
  const response = await fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal,
  })

  if (!response.ok) {
    const err = await response.json().catch(() => ({ error: { message: '请求失败' } }))
    throw new Error(err?.error?.message || `HTTP ${response.status}`)
  }

  const reader = response.body?.getReader()
  if (!reader) throw new Error('不支持流式响应')

  const decoder = new TextDecoder()
  let buffer = ''

  function* parseBuffer(chunk: string): Generator<SSEEvent> {
    buffer += chunk
    const lines = buffer.split('\n')
    buffer = lines.pop() || ''

    let currentEvent = ''
    for (const line of lines) {
      if (line.startsWith('event: ')) {
        currentEvent = line.slice(7).trim()
      } else if (line.startsWith('data: ')) {
        const jsonStr = line.slice(6).trim()
        if (!jsonStr) continue
        try {
          const data = JSON.parse(jsonStr)
          yield { event: currentEvent, data }
          currentEvent = ''
        } catch {
          // malformed JSON, skip
        }
      }
    }
  }

  try {
    while (true) {
      const { done, value } = await reader.read()
      if (done) {
        // Flush remaining buffer (final event may lack trailing \n)
        if (buffer.trim()) {
          const finalChunk = buffer + '\n'
          buffer = ''
          yield* parseBuffer(finalChunk)
        }
        break
      }

      const chunk = decoder.decode(value, { stream: true })
      yield* parseBuffer(chunk)
    }
  } finally {
    reader.releaseLock()
  }
}
