<script setup lang="ts">
import { ref, watch } from 'vue'
import { useContextStore } from '@/stores/context'
import { nodeColors } from '@/theme/palette'

const props = defineProps<{
  detail: any | null
  loading: boolean
}>()

const emit = defineEmits<{
  'add-context': [node: any]
  'locate': [id: string]
}>()

const context = useContextStore()
const collapsed = ref(false)
const expandReasoning = ref(false)

function addToContext() {
  if (!props.detail) return
  emit('add-context', {
    id: props.detail.id,
    idKind: props.detail.idKind,
    name: props.detail.name,
    label: props.detail.label,
    type_cn: props.detail.type_cn,
    color: nodeColors[props.detail.label] || '#9A938A',
    addedFrom: 'explore' as const,
  })
}

function isInContext(id: string): boolean {
  return context.items.some((i) => i.id === id)
}
</script>

<template>
  <aside class="left-archive" :class="{ collapsed }">
    <!-- 折叠把手 -->
    <button class="collapse-handle" @click="collapsed = !collapsed" :title="collapsed ? '展开' : '折叠'">
      {{ collapsed ? '▶' : '◀' }}
    </button>

    <div v-if="!collapsed" class="archive-content">
      <!-- 加载骨架 -->
      <div v-if="loading" class="skeleton">
        <div class="sk-line w-60"></div>
        <div class="sk-line w-40"></div>
        <div class="sk-line w-80"></div>
        <div class="sk-line w-50"></div>
        <div class="sk-line w-full"></div>
      </div>

      <!-- 空状态 -->
      <div v-else-if="!detail" class="empty">
        <div class="empty-icon">📋</div>
        <p>请在图中点击一个节点</p>
        <p class="empty-sub">以查看其档案与属性</p>
      </div>

      <!-- 节点详情 -->
      <template v-else>
        <!-- 标题区 -->
        <div class="detail-header">
          <h2 class="node-name">{{ detail.name }}</h2>
          <div class="node-tags">
            <span
              class="type-tag"
              :style="{
                background: (nodeColors[detail.label] || '#9A938A') + '1F',
                color: nodeColors[detail.label] || '#9A938A',
                borderColor: nodeColors[detail.label] || '#9A938A',
              }"
            >
              {{ detail.type_cn }}
            </span>
            <span v-if="detail.subtype_cn" class="subtype">{{ detail.subtype_cn }}</span>
            <span class="degree">度数 {{ detail.degree }}</span>
          </div>
        </div>

        <!-- 加入上下文篮 -->
        <button
          class="btn-context"
          @click="addToContext"
          :disabled="isInContext(detail.id)"
        >
          {{ isInContext(detail.id) ? '已在上下文篮中' : '＋ 加入 AI 上下文' }}
        </button>

        <!-- 属性列表 -->
        <div class="props-section">
          <h3 class="section-title">属性</h3>
          <dl class="props-list" v-if="detail.properties && detail.properties.length">
            <div
              v-for="prop in detail.properties"
              :key="prop.key"
              class="prop-row"
            >
              <dt>{{ prop.cn }}</dt>
              <dd>{{ prop.value || '暂无' }}</dd>
            </div>
          </dl>
          <p v-else class="no-data">暂无属性信息</p>
        </div>

        <!-- 推理说明（可折叠） -->
        <div v-if="detail.properties?.find((p: any) => p.key === 'reasoning')?.value" class="reasoning-section">
          <button class="reasoning-toggle" @click="expandReasoning = !expandReasoning">
            {{ expandReasoning ? '▾' : '▸' }} 推理说明
          </button>
          <p v-if="expandReasoning" class="reasoning-text">
            {{ detail.properties.find((p: any) => p.key === 'reasoning')?.value }}
          </p>
        </div>

        <!-- 原档案文本 -->
        <div v-if="detail.sourceText" class="source-section">
          <h3 class="section-title">原档案文本</h3>
          <div class="source-text">
            {{ detail.sourceText }}
          </div>
        </div>

        <!-- 档案图片占位（为未来预留） -->
        <div class="image-placeholder">
          <h3 class="section-title">档案影像</h3>
          <div class="img-placeholder-box">
            <span>📷</span>
            <p>（暂未接入档案影像）</p>
          </div>
        </div>
      </template>
    </div>
  </aside>
</template>

<style scoped>
.left-archive {
  position: relative;
  width: 320px;
  background: var(--bg-panel);
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  transition: width 0.2s ease-out;
  overflow: hidden;
}

.left-archive.collapsed {
  width: 32px;
}

.collapse-handle {
  position: absolute;
  top: 50%;
  right: 0;
  transform: translateY(-50%);
  width: 20px;
  height: 48px;
  background: var(--bg-subtle);
  border: 1px solid var(--border);
  border-right: none;
  border-radius: var(--radius-sm) 0 0 var(--radius-sm);
  cursor: pointer;
  font-size: 10px;
  color: var(--text-muted);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 5;
  transition: color 0.15s;
}

.collapse-handle:hover {
  color: var(--accent);
}

.archive-content {
  padding: 20px;
  overflow-y: auto;
  height: 100%;
}

/* 骨架 */
.skeleton .sk-line {
  height: 16px;
  background: var(--bg-subtle);
  border-radius: 3px;
  margin-bottom: 12px;
  animation: sk-pulse 1.5s ease-in-out infinite;
}
.sk-line.w-60 { width: 60%; }
.sk-line.w-40 { width: 40%; }
.sk-line.w-80 { width: 80%; }
.sk-line.w-50 { width: 50%; }
.sk-line.w-full { width: 100%; }

@keyframes sk-pulse {
  0%, 100% { opacity: 0.4; }
  50% { opacity: 0.8; }
}

/* 空 */
.empty {
  text-align: center;
  padding-top: 60px;
  color: var(--text-muted);
}
.empty-icon { font-size: 36px; margin-bottom: 12px; opacity: 0.5; }
.empty p { font-size: 14px; }
.empty-sub { font-size: 12px; margin-top: 4px; }

/* 详情 */
.detail-header { margin-bottom: 16px; }
.node-name {
  font-size: 17px;
  font-weight: 600;
  color: var(--text-primary);
  line-height: 1.5;
  margin-bottom: 8px;
}
.node-tags {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}
.type-tag {
  padding: 2px 8px;
  border-radius: var(--radius-sm);
  font-size: 12px;
  border: 1px solid;
}
.subtype {
  font-size: 12px;
  color: var(--text-secondary);
}
.degree {
  font-size: 12px;
  color: var(--text-muted);
}

.btn-context {
  width: 100%;
  padding: 6px 12px;
  margin-bottom: 20px;
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  background: var(--bg-subtle);
  font-size: 13px;
  font-family: inherit;
  color: var(--text-primary);
  cursor: pointer;
  transition: all 0.15s;
}
.btn-context:hover:not(:disabled) {
  border-color: var(--accent);
  color: var(--accent);
}
.btn-context:disabled {
  opacity: 0.5;
  cursor: default;
}

.section-title {
  font-size: 14px;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 10px;
  padding-bottom: 6px;
  border-bottom: 1px solid var(--bg-subtle);
}

.props-list { margin-bottom: 20px; }
.prop-row {
  display: flex;
  gap: 12px;
  padding: 4px 0;
  font-size: 13px;
  line-height: 1.6;
}
.prop-row dt {
  width: 90px;
  flex-shrink: 0;
  color: var(--text-secondary);
}
.prop-row dd {
  flex: 1;
  color: var(--text-primary);
}
.no-data {
  font-size: 13px;
  color: var(--text-muted);
  padding: 8px 0;
}

.reasoning-section {
  margin-bottom: 20px;
}
.reasoning-toggle {
  background: none;
  border: none;
  font-size: 13px;
  font-family: inherit;
  color: var(--text-secondary);
  cursor: pointer;
  padding: 4px 0;
}
.reasoning-text {
  font-size: 13px;
  color: var(--text-secondary);
  line-height: 1.7;
  padding: 8px;
  background: var(--bg-subtle);
  border-radius: var(--radius-sm);
  margin-top: 6px;
}

.source-section { margin-bottom: 20px; }
.source-text {
  font-family: "Source Han Serif SC", "Songti SC", "SimSun", serif;
  font-size: 15px;
  line-height: 1.9;
  color: var(--text-primary);
  background: var(--bg-canvas);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  padding: 14px;
  max-height: 300px;
  overflow-y: auto;
  white-space: pre-wrap;
  word-break: break-all;
}

.image-placeholder { margin-bottom: 20px; }
.img-placeholder-box {
  border: 2px dashed var(--border);
  border-radius: var(--radius);
  padding: 30px;
  text-align: center;
  color: var(--text-muted);
  font-size: 13px;
}
.img-placeholder-box span { font-size: 28px; opacity: 0.4; }
.img-placeholder-box p { margin-top: 8px; }
</style>
