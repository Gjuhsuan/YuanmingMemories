/**
 * Pinia：AI 问答页状态
 */
import { defineStore } from 'pinia'
import { streamChat, type SSEEvent } from '@/api/chat'
import { useContextStore } from './context'

export interface ChatMessage {
  role: 'user' | 'assistant'
  content: string
  citations?: { id: string; marker: string }[]
  retrievalGraph?: { nodes: any[]; edges: any[] }
}

export const useChatStore = defineStore('chat', {
  state: () => ({
    sessionId: null as string | null,
    messages: [] as ChatMessage[],
    streaming: false,
    ragGraph: null as { nodes: any[]; edges: any[] } | null,
    citedIds: [] as string[],
    error: null as string | null,
    abortCtrl: null as AbortController | null,
  }),

  actions: {
    async ask(question: string) {
      if (this.streaming) return

      const contextStore = useContextStore()
      const pinnedIds = contextStore.pinnedIds

      // 历史（近 6 轮 = 12 条）
      const history = this.messages.slice(-12).map((m) => ({
        role: m.role,
        content: m.content,
      }))

      this.streaming = true
      this.error = null
      this.ragGraph = null
      this.citedIds = []

      // 添加用户消息
      this.messages.push({ role: 'user', content: question })

      // 准备 AI 消息占位
      const aiMsg: ChatMessage = { role: 'assistant', content: '', citations: [] }
      this.messages.push(aiMsg)

      this.abortCtrl = new AbortController()

      try {
        for await (const sse of streamChat(
          {
            sessionId: this.sessionId,
            question,
            pinnedNodeIds: pinnedIds,
            history,
          },
          this.abortCtrl.signal,
        )) {
          this._handleSSE(sse, aiMsg)
        }
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          this.error = err.message || '请求失败'
          aiMsg.content = aiMsg.content || `（错误：${this.error}）`
        }
      } finally {
        this.streaming = false
        this.abortCtrl = null
      }
    },

    _handleSSE(sse: SSEEvent, aiMsg: ChatMessage) {
      switch (sse.event) {
        case 'session':
          this.sessionId = sse.data.sessionId
          break
        case 'retrieval':
          this.ragGraph = sse.data.graph
          aiMsg.retrievalGraph = sse.data.graph
          break
        case 'token':
          aiMsg.content += sse.data.text || ''
          break
        case 'citation':
          if (sse.data.nodeIds) {
            for (const nid of sse.data.nodeIds) {
              if (!this.citedIds.includes(nid)) {
                this.citedIds.push(nid)
              }
            }
          }
          if (!aiMsg.citations) aiMsg.citations = []
          aiMsg.citations.push(sse.data)
          break
        case 'done':
          // 完成
          break
        case 'error':
          this.error = sse.data.message || '未知错误'
          break
      }
    },

    stop() {
      if (this.abortCtrl) {
        this.abortCtrl.abort()
        this.abortCtrl = null
      }
      this.streaming = false
    },

    reset() {
      this.stop()
      this.sessionId = null
      this.messages = []
      this.ragGraph = null
      this.citedIds = []
      this.error = null
    },
  },
})
