"""
Neo4j 记录 → 前端 graph payload 整形。

核心职责：
- 统一 id/idKind（event_id vs entity_id）
- 统一节点/边的 JSON 格式
- 不会丢失 Neo4j 原生属性
"""
from ..config import CLASS_CN
from .palette import get_node_color
from . import LABEL_CN


def _node_id(neo4j_node) -> tuple[str, str]:
    """
    返回 (id, idKind)。
    Event 用 event_id，其余实体用 entity_id。
    """
    labels = list(neo4j_node.labels)
    if "Event" in labels and neo4j_node.get("event_id"):
        return neo4j_node["event_id"], "event"
    eid = neo4j_node.get("entity_id", "")
    if eid:
        return eid, "entity"
    # fallback
    return str(neo4j_node.element_id), "entity"


def _node_label(neo4j_node) -> str:
    """取顶层 Label（Event > Person > Place > ...）"""
    labels = list(neo4j_node.labels)
    priority = [
        "Event", "Person", "Place", "Organization", "Object",
        "Document", "AbstractNorm", "TemporalInterval",
    ]
    for p in priority:
        if p in labels:
            return p
    return labels[0] if labels else "Unknown"


def shape_node(neo4j_node, degree: int = 0, size: float = 24.0) -> dict:
    """把单个 Neo4j Node 整形为前端 GraphNode dict。"""
    nid, id_kind = _node_id(neo4j_node)
    label = _node_label(neo4j_node)
    type_cn = LABEL_CN.get(label, label)
    subtype = neo4j_node.get("entity_type_cn") or neo4j_node.get("event_type_cn") or ""
    name = neo4j_node.get("name", "") or ""
    date_text = neo4j_node.get("date_text", "") or ""

    return {
        "id": nid,
        "idKind": id_kind,
        "label": label,
        "type_cn": type_cn,
        "name": name,
        "subtype_cn": subtype,
        "degree": degree,
        "size": size,
        "color": get_node_color(label),
        "date_text": date_text,
        "cited": False,
    }


def shape_edge(neo4j_rel) -> dict:
    """把单个 Neo4j Relationship 整形为前端 GraphEdge dict。"""
    rel_type = neo4j_rel.type
    relation_cn = neo4j_rel.get("relation_cn", "") or ""
    return {
        "id": f"{neo4j_rel.start_node.element_id}->{neo4j_rel.end_node.element_id}",
        "source": _node_id(neo4j_rel.start_node)[0],
        "target": _node_id(neo4j_rel.end_node)[0],
        "type": rel_type,
        "type_cn": relation_cn,
    }


def shape_node_detail(neo4j_node, degree: int = 0) -> dict:
    """
    把单个 Neo4j Node 整形为前端 NodeDetail dict（含全部属性 + sourceText）。
    """
    nid, id_kind = _node_id(neo4j_node)
    label = _node_label(neo4j_node)
    type_cn = LABEL_CN.get(label, label)
    subtype = neo4j_node.get("entity_type_cn") or neo4j_node.get("event_type_cn") or ""
    name = neo4j_node.get("name", "") or ""
    source_text = neo4j_node.get("source_text", "") or ""
    doc_title = neo4j_node.get("document_title", "") or ""

    from ..config import DATA_PROPERTY_CN, OBJECT_PROPERTY_CN

    # 属性映射
    prop_keys = list(neo4j_node.keys())
    properties = []
    for k in prop_keys:
        if k in ("name", "event_id", "entity_id", "event_type", "entity_type",
                 "event_type_cn", "entity_type_cn", "source_text", "document_title"):
            continue
        v = neo4j_node.get(k)
        if v is None:
            v = ""
        cn = DATA_PROPERTY_CN.get(k) or OBJECT_PROPERTY_CN.get(k) or k
        properties.append({"key": k, "cn": cn, "value": v if v else ""})

    return {
        "id": nid,
        "idKind": id_kind,
        "label": label,
        "type_cn": type_cn,
        "subtype_cn": subtype,
        "name": name,
        "properties": properties,
        "sourceText": source_text,
        "degree": degree,
        "documentTitle": doc_title,
        "images": [],
    }
