"""
RAG 流式问答路由 — SSE 协议。

POST /api/chat —— 主问答流式接口（SSE）
POST /api/chat/retrieve —— 纯检索（调试/预览用）
"""
import json
import time
import uuid
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse

from ..schemas import ChatRequest, ChatRetrieveResponse, GraphPayload
from ..services.retrieval import entity_linking, subgraph_expand, serialize_context
from ..services.llm import stream_chat, is_available
from ..services.prompt import (
    SYSTEM_PROMPT,
    build_user_message,
    parse_citations,
    build_pinned_summaries,
)

router = APIRouter(prefix="/api/chat")

# ── 简易内存会话存储 ──
_sessions: dict[str, list[dict]] = {}


def _get_or_create_session(session_id: str | None) -> str:
    if session_id and session_id in _sessions:
        return session_id
    new_id = session_id or uuid.uuid4().hex[:12]
    if new_id not in _sessions:
        _sessions[new_id] = []
    return new_id


def _load_pinned_node_details(pinned_ids: list[str]) -> list[dict]:
    """加载上下文篮中节点的完整信息用于摘要。"""
    if not pinned_ids:
        return []
    from ..db import execute_read

    results = []
    for nid in pinned_ids:
        query = """
        MATCH (n) WHERE n.event_id = $nid OR n.entity_id = $nid
        RETURN n LIMIT 1
        """
        recs = execute_read(query, {"nid": nid})
        if recs:
            node = recs[0]["n"]
            from ..services.shaper import _node_id, _node_label
            from ..config import CLASS_CN
            n_id, n_kind = _node_id(node)
            label = _node_label(node)
            results.append({
                "id": n_id,
                "name": node.get("name", ""),
                "label": label,
                "type_cn": CLASS_CN.get(label, label),
            })
    return results


# ───────────────────────────────── POST /api/chat (SSE) ──────────────────
@router.post("")
async def chat(request: Request, body: ChatRequest):
    """
    RAG 流式问答，返回 SSE 事件流。
    事件序列：session → retrieval → token... → citation → done
    """
    session_id = _get_or_create_session(body.sessionId)
    question = body.question.strip()
    if not question:
        raise HTTPException(status_code=400, detail="问题不能为空")

    if len(question) > 2000:
        raise HTTPException(status_code=400, detail="问题长度超过限制（2000字）")

    async def event_stream():
        # ① 实体链接
        seeds = entity_linking(question)
        seed_ids = [s["id"] for s in seeds]

        # ② 合并 pinned 节点
        pinned_ids = body.pinnedNodeIds or []
        for pid in pinned_ids:
            if pid not in seed_ids:
                seed_ids.append(pid)

        # ③④ 子图扩展 + 序列化
        t0 = time.time()
        hops = body.options.get("hops", 1) if body.options else 1
        topk = body.options.get("retrieveTopK", 40) if body.options else 40
        result = subgraph_expand(seed_ids, hops=hops, topk=topk)

        took_ms = int((time.time() - t0) * 1000)
        graph = result["graph"]
        context_text = result.get("context", "")

        # 发送 retrieval 事件（先发，前端可先渲染子图）
        retrieval_data = {
            "graph": graph,
            "seedIds": seed_ids,
            "tookMs": took_ms,
        }
        yield f"event: retrieval\ndata: {json.dumps(retrieval_data, ensure_ascii=False)}\n\n"

        # 发送 session 事件
        yield f"event: session\ndata: {json.dumps({'sessionId': session_id})}\n\n"

        # ⑤ 构建可引用清单
        allowed_ids = [n["id"] for n in graph["nodes"]]

        # ⑥ 加载 pinned 摘要
        pinned_details = _load_pinned_node_details(pinned_ids)
        pinned_summaries = build_pinned_summaries(pinned_details)

        # ⑦ 组装消息
        user_message = build_user_message(
            question=question,
            serialized_subgraph=context_text,
            allowed_ids=allowed_ids,
            pinned_summaries=pinned_summaries,
        )

        # 历史（最多 6 轮 = 12 条消息）
        history = body.history[-12:] if body.history else []

        messages = []
        for h in history:
            messages.append({"role": h.role, "content": h.content})
        messages.append({"role": "user", "content": user_message})

        # 保存到会话
        _sessions[session_id].append({"role": "user", "content": question})

        # ⑧ 流式调用 LLM
        full_text = ""
        all_citations = []

        if is_available():
            async for event in stream_chat(messages, system=SYSTEM_PROMPT):
                if event["type"] == "token":
                    full_text += event["text"]
                    yield f"event: token\ndata: {json.dumps({'text': event['text']}, ensure_ascii=False)}\n\n"
                elif event["type"] == "done":
                    # 解析引用
                    citations = parse_citations(full_text, allowed_ids)
                    all_citations = citations
                    for c in citations:
                        yield f"event: citation\ndata: {json.dumps(c, ensure_ascii=False)}\n\n"

                    done_data = {
                        'usage': event.get('usage', {}),
                        'citations': citations,
                        'finishReason': event.get('finishReason', 'stop'),
                    }
                    yield f"event: done\ndata: {json.dumps(done_data, ensure_ascii=False)}\n\n"

                    # 保存到会话
                    _sessions[session_id].append({
                        "role": "assistant",
                        "content": full_text,
                        "citations": citations,
                    })
                elif event["type"] == "error":
                    err_data = {
                        'code': 'LLM_ERROR',
                        'message': event['message'],
                    }
                    yield f"event: error\ndata: {json.dumps(err_data, ensure_ascii=False)}\n\n"
        else:
            # 无 LLM：返回检索结果作为响应
            fallback = f"（LLM 未配置）\n\n根据图谱检索结果，共找到 {len(graph['nodes'])} 个相关节点。\n\n{context_text[:500]}"
            full_text = fallback
            for ch in fallback:
                yield f"event: token\ndata: {json.dumps({'text': ch}, ensure_ascii=False)}\n\n"
            fallback_done = {
                'usage': {'inputTokens': 0, 'outputTokens': len(fallback)},
                'citations': [],
                'finishReason': 'stop',
            }
            yield f"event: done\ndata: {json.dumps(fallback_done, ensure_ascii=False)}\n\n"

            _sessions[session_id].append({
                "role": "assistant",
                "content": full_text,
                "citations": [],
            })

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


# ─────────────────── POST /api/chat/retrieve（纯检索） ───────────────────
@router.post("/retrieve", response_model=ChatRetrieveResponse)
async def chat_retrieve(body: ChatRequest):
    """仅执行 GraphRAG 检索，不调用 LLM。用于联调检索质量。"""
    seeds = entity_linking(body.question)
    seed_ids = [s["id"] for s in seeds]

    pinned_ids = body.pinnedNodeIds or []
    for pid in pinned_ids:
        if pid not in seed_ids:
            seed_ids.append(pid)

    t0 = time.time()
    hops = body.options.get("hops", 1) if body.options else 1
    topk = body.options.get("retrieveTopK", 40) if body.options else 40
    result = subgraph_expand(seed_ids, hops=hops, topk=topk)

    took_ms = int((time.time() - t0) * 1000)

    return ChatRetrieveResponse(
        graph=GraphPayload(
            nodes=result["graph"]["nodes"],
            edges=result["graph"]["edges"],
            meta={},
        ),
        seeds=seed_ids,
        contextText=result.get("context", ""),
        tookMs=took_ms,
    )


# ─────────────────────── /api/chat/sessions ───────────────────────
@router.get("/sessions/{session_id}")
async def get_session(session_id: str):
    """获取会话历史。"""
    if session_id not in _sessions:
        raise HTTPException(status_code=404, detail="会话未找到")
    return {"sessionId": session_id, "messages": _sessions[session_id]}


@router.delete("/sessions/{session_id}")
async def delete_session(session_id: str):
    """删除会话。"""
    if session_id in _sessions:
        del _sessions[session_id]
    return {"deleted": True}
