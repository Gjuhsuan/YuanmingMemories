"""
环境变量集中读取。
所有敏感配置从环境变量注入，绝不硬编码。
"""
import os

# ── Neo4j ──
NEO4J_URI = os.environ.get("NEO4J_URI", "bolt://localhost:7687")
NEO4J_USER = os.environ.get("NEO4J_USER", "neo4j")
NEO4J_PASSWORD = os.environ.get("NEO4J_PASSWORD", "ymysj123")
NEO4J_DATABASE = os.environ.get("NEO4J_DATABASE", "neo4j")

# ── LLM Provider ──
# 支持 openai 兼容协议（DeepSeek / OpenAI / 国产模型等）和 anthropic 原生协议
LLM_PROVIDER = os.environ.get("LLM_PROVIDER", "openai")  # "openai" | "anthropic"
LLM_API_KEY = os.environ.get("LLM_API_KEY", "sk-ee064abcc7f741ad81371b711f151b64")
LLM_BASE_URL = os.environ.get("LLM_BASE_URL", "https://api.deepseek.com/v1")
LLM_MODEL = os.environ.get("LLM_MODEL", "deepseek-chat")
LLM_MAX_TOKENS = int(os.environ.get("LLM_MAX_TOKENS", "2048"))

# ── RAG ──
RAG_RETRIEVE_TOPK = int(os.environ.get("RAG_RETRIEVE_TOPK", "40"))
RAG_HOPS = int(os.environ.get("RAG_HOPS", "2"))
RAG_MAX_CONTEXT_TOKENS = int(os.environ.get("RAG_MAX_CONTEXT_TOKENS", "8000"))
RAG_MAX_SOURCE_CHARS = int(os.environ.get("RAG_MAX_SOURCE_CHARS", "300"))

# ── Rate Limiting ──
CHAT_RATE_LIMIT_PER_MINUTE = int(os.environ.get("CHAT_RATE_LIMIT_PER_MINUTE", "20"))

# ── CORS ──
CORS_ORIGINS = os.environ.get("CORS_ORIGINS", "http://localhost:5173,http://localhost:3000").split(",")
