#!/bin/bash
# 圆明园事件知识图谱 Web 系统 — 一键启动脚本
# 用法：bash start.sh [dev|prod]

set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

MODE="${1:-dev}"

echo "========================================"
echo "  圆明园事件知识图谱 Web 系统"
echo "========================================"

if [ "$MODE" = "prod" ]; then
    echo "[1/2] 构建前端..."
    cd frontend && npm install --silent && npm run build && cd ..
    echo "[2/2] 启动后端（含静态文件）..."
    uvicorn backend.main:app --host 0.0.0.0 --port 8000
else
    echo "[开发模式]"
    echo "  终端1: cd backend && uvicorn backend.main:app --reload --port 8000"
    echo "  终端2: cd frontend && npm install && npm run dev"
    echo ""
    echo "启动后端..."
    uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000 &
    sleep 2
    echo "启动前端..."
    cd frontend && npm run dev
fi
